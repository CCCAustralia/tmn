<?php

    namespace Unirest;

    interface HttpMethod
    {

        const DELETE = "DELETE";
        const GET = "GET";
        const POST = "POST";
        const PUT = "PUT";
        const PATCH = "PATCH";

    }
    